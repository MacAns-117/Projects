from django.urls import path
from app1 import views

urlpatterns = [
   path("dis/<slug:Name>/",views.display,name="display"),
   path("details/",views.details,name="details"),
]
