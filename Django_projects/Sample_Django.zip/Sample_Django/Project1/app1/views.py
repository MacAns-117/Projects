from django.shortcuts import render,HttpResponse
from app1.models import Patient

# Create your views here.
def display(request,Name):
    AllPost=Patient.objects.filter(Name=Name)
    context={"AllPost":AllPost}
    
    return render(request,"index.html",context)
def details(request):
    if request.method == "POST":
        Name=request.POST.get("Name")
        Blood_group=request.POST.get("Blood_group")
        Age=request.POST.get("Age")
        Disease=request.POST.get("Disease")
        Location=request.POST.get("Location")
        query=Patient(Name=Name,Blood_group=Blood_group,Age=Age,Disease=Disease,Location=Location)
        query.save()
        return HttpResponse("Successfully Saved")
    return render(request,"details.html")